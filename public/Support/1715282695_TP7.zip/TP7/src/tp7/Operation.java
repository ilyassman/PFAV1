package tp7;

import java.time.LocalDate;

public class Operation {
	
	private LocalDate date;
	private float  montant;
	private String libelle ;
	
	public Operation(String libelle,float montant) {
		this.date = LocalDate.now();
		this.montant = montant;
		this.libelle = libelle;
	}
	
	public String toString() {
		return date + " | " + libelle + " | " + montant ;
	}

}
