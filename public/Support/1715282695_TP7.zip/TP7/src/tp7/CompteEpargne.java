package tp7;

public class CompteEpargne extends CompteBancaire {

	private float taux;
	
	public CompteEpargne(String client, float sold,float taux) {
		super(client,sold);
		this.taux = taux;
	}
	
	public void calculInteret() {
        float interet = super.getSolde() * taux / 100;
        super.setSolde(super.getSolde() + interet);
	}
	
}
