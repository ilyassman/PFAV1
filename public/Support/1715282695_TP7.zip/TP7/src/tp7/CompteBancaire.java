package tp7;

import java.time.LocalDate;
import java.util.ArrayList;

public class CompteBancaire {
	
	private static int compteur = 1;
	private int id;
	private String client;
	private float solde;
	private LocalDate dateOuverture ;
	private ArrayList<Operation> operations;
	
	public CompteBancaire(String client) {
		this.client = client;
		this.dateOuverture = LocalDate.now();
		this.solde = 0;
		this.operations = new ArrayList<>();
		id=compteur++;
	}
	
	public CompteBancaire(String client, float solde) {
		this.client = client;
		this.dateOuverture = LocalDate.now();
		this.solde = solde;
		this.operations = new ArrayList<>();
		id=compteur++;
	}
	
	
	public void verser(float argent) {
		this.solde += argent;
		Operation op = new Operation("versement",argent);
		operations.add(op);
	}
	
	public void retirer(float argent) throws SoldeInsuffisantException{
		if(solde < argent)
			throw new SoldeInsuffisantException("Le solde à retirer est plus que le solde du compte",solde);
		this.solde-=argent;
		Operation op = new Operation("retrait",argent);
		operations.add(op);
	}
	
	
	public void historique() {
		System.out.println("------------------------------------------------------");
		System.out.println("Compete No :" + id +"      Client: " + client  +"     " + LocalDate.now() );
		System.out.println("Dernieres "+ operations.size() + " operations");
		System.out.println("------------------------------------------------------");
		for (Operation operation : operations) {
			System.out.println(operation);
		}
	}
	
	public float getSolde() {
		return this.solde;
	}
	
	
	public void setSolde(float solde) {
		this.solde=solde;
	}

	public ArrayList<Operation> getOperations() {
        return operations;
    }
}
