package tp7;

public class CompteCourant extends CompteBancaire {
	private float decouvert = 1000;
	
	public CompteCourant(String client) {
		super(client);
	}
	
	public CompteCourant(String client, float solde) {
		super(client,solde);
	}
	
	public CompteCourant(String client, float solde,float decouvert) {
		super(client,solde);
		this.decouvert = decouvert;
	}
	
	@Override
	public void retirer(float argent) throws SoldeInsuffisantException{
		if(super.getSolde() - argent < -decouvert)
			throw new SoldeInsuffisantException("Le solde à retirer est plus que le decouvert du compte",decouvert + super.getSolde());
		
		super.setSolde(super.getSolde()-argent);
		super.getOperations().add(new Operation("retirer",argent));
		
	}
}
