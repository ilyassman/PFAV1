package tp7;

public class SoldeInsuffisantException extends Exception {
	
	private float montant;
	
	public SoldeInsuffisantException(String msg, float montant) {
		super(msg);
		this.montant=montant;
	}
	
	public String getDetailledMessage() {
		return getMessage() + " le montant autorisé pour le retrait: " + montant;
	}

}
