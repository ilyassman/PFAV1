package tp7;

public class Banque {
    public static void main(String[] args) {
        CompteBancaire cb = new CompteBancaire("Amine", 1000);
        CompteBancaire cc = new CompteCourant("Ahmed", 1000,2000);
        CompteBancaire ce = new CompteEpargne("Ayoub", 1000,2);


        try {
            cb.verser(1000);
            cb.retirer(2000); 
            cb.retirer(400); 
        } catch (SoldeInsuffisantException e) {
            System.out.println(e.getDetailledMessage());
        }
        
        try {
            cc.verser(1000);
            cc.retirer(4000); 
            cc.retirer(500); 
        } catch (SoldeInsuffisantException e) {
            System.out.println(e.getDetailledMessage());
        }
        
        try {
            ce.verser(1000);
            ce.retirer(2000); 
            ce.retirer(400); 
        } catch (SoldeInsuffisantException e) {
            System.out.println(e.getDetailledMessage());
        }

        cb.historique();
        cc.historique();
        ce.historique();
    }
}
